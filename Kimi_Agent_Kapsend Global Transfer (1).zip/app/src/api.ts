// NKAPSEND API Service
// Update this URL after deploying your backend
const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://nkapsend-api.onrender.com/api';

// Helper for API calls
async function apiCall(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    headers: {
      'Content-Type': 'application/json',
    },
    ...options,
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'API Error');
  }
  
  return response.json();
}

// ========== AUTHENTICATION ==========

export async function registerUser(userData: {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  country: string;
}) {
  return apiCall('/auth/register', {
    method: 'POST',
    body: JSON.stringify(userData),
  });
}

export async function loginUser(credentials: {
  email: string;
  password: string;
}) {
  return apiCall('/auth/login', {
    method: 'POST',
    body: JSON.stringify(credentials),
  });
}

// ========== PAYMENTS ==========

export async function createPaymentIntent(paymentData: {
  amount: number;
  currency: string;
  recipientEmail: string;
  recipientCountry: string;
  paymentMethod: string;
}) {
  return apiCall('/payments/create-intent', {
    method: 'POST',
    body: JSON.stringify(paymentData),
  });
}

export async function confirmPayment(confirmData: {
  paymentIntentId: string;
  senderId: string;
  recipientName: string;
  recipientPhone: string;
  recipientCountry: string;
}) {
  return apiCall('/payments/confirm', {
    method: 'POST',
    body: JSON.stringify(confirmData),
  });
}

// ========== PAYPAL ==========

export async function createPayPalOrder(orderData: {
  amount: number;
  currency: string;
  paypalEmail: string;
  mobileProvider: string;
  mobileNumber: string;
}) {
  return apiCall('/paypal/create-order', {
    method: 'POST',
    body: JSON.stringify(orderData),
  });
}

export async function capturePayPalPayment(captureData: {
  orderId: string;
  userId: string;
  paypalEmail: string;
  amount: number;
}) {
  return apiCall('/paypal/capture', {
    method: 'POST',
    body: JSON.stringify(captureData),
  });
}

// ========== BILLS ==========

export async function payBill(billData: {
  userId: string;
  billType: string;
  provider: string;
  accountNumber: string;
  amount: number;
  currency: string;
  country: string;
}) {
  return apiCall('/bills/pay', {
    method: 'POST',
    body: JSON.stringify(billData),
  });
}

// ========== TRANSACTIONS ==========

export async function getUserTransactions(userId: string) {
  return apiCall(`/transactions/${userId}`);
}

export async function getTransactionDetail(transactionId: string) {
  return apiCall(`/transactions/detail/${transactionId}`);
}

// ========== EXCHANGE RATES ==========

export async function getExchangeRates() {
  return apiCall('/exchange-rates');
}

// ========== STRIPE CLIENT-SIDE ==========

// Load Stripe.js
export function loadStripeScript(): Promise<void> {
  return new Promise((resolve, reject) => {
    if ((window as any).Stripe) {
      resolve();
      return;
    }
    
    const script = document.createElement('script');
    script.src = 'https://js.stripe.com/v3/';
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load Stripe'));
    document.head.appendChild(script);
  });
}

// Initialize Stripe
export function initializeStripe(publishableKey: string) {
  return (window as any).Stripe(publishableKey);
}
