import { useState, useEffect } from 'react';
import { loadStripeScript, initializeStripe, createPaymentIntent, confirmPayment } from '../api';
import { CreditCard, Lock, CheckCircle2, Loader2 } from 'lucide-react';

interface StripePaymentProps {
  amount: number;
  currency: string;
  recipientEmail: string;
  recipientCountry: string;
  paymentMethod: string;
  senderId: string;
  recipientName: string;
  recipientPhone: string;
  onSuccess: (transaction: any) => void;
  onCancel: () => void;
}

export default function StripePayment({
  amount,
  currency,
  recipientEmail,
  recipientCountry,
  paymentMethod,
  senderId,
  recipientName,
  recipientPhone,
  onSuccess,
  onCancel,
}: StripePaymentProps) {
  const [stripe, setStripe] = useState<any>(null);
  const [elements, setElements] = useState<any>(null);
  const [cardElement, setCardElement] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [paymentDetails, setPaymentDetails] = useState<any>(null);

  useEffect(() => {
    initializeStripePayment();
  }, []);

  async function initializeStripePayment() {
    try {
      // Load Stripe.js
      await loadStripeScript();
      
      // Initialize Stripe with publishable key
      const stripeInstance = initializeStripe(
        import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || 'pk_test_your_key'
      );
      setStripe(stripeInstance);
      
      // Create Elements
      const elementsInstance = stripeInstance.elements({
        appearance: {
          theme: 'stripe',
          variables: {
            colorPrimary: '#00A86B',
            colorBackground: '#ffffff',
            colorText: '#1a1a1a',
            colorDanger: '#ef4444',
            fontFamily: 'system-ui, sans-serif',
            spacingUnit: '4px',
            borderRadius: '12px',
          },
        },
      });
      setElements(elementsInstance);
      
      // Create and mount card element
      const card = elementsInstance.create('card', {
        style: {
          base: {
            fontSize: '16px',
            color: '#1a1a1a',
            '::placeholder': {
              color: '#9ca3af',
            },
          },
          invalid: {
            color: '#ef4444',
          },
        },
      });
      
      // Mount to container
      const cardContainer = document.getElementById('card-element');
      if (cardContainer) {
        card.mount('#card-element');
        setCardElement(card);
      }
      
      // Create payment intent on backend
      const intent = await createPaymentIntent({
        amount,
        currency,
        recipientEmail,
        recipientCountry,
        paymentMethod,
      });
      
      setClientSecret(intent.clientSecret);
      setPaymentDetails(intent);
      setLoading(false);
    } catch (err: any) {
      setError(err.message || 'Failed to initialize payment');
      setLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    
    if (!stripe || !elements || !clientSecret) {
      return;
    }
    
    setProcessing(true);
    setError(null);
    
    try {
      // Confirm card payment
      const { error: confirmError, paymentIntent } = await stripe.confirmCardPayment(
        clientSecret,
        {
          payment_method: {
            card: cardElement,
            billing_details: {
              name: recipientName,
              email: recipientEmail,
            },
          },
        }
      );
      
      if (confirmError) {
        throw new Error(confirmError.message);
      }
      
      if (paymentIntent.status === 'succeeded') {
        // Confirm payment on backend
        const result = await confirmPayment({
          paymentIntentId: paymentIntent.id,
          senderId,
          recipientName,
          recipientPhone,
          recipientCountry,
        });
        
        onSuccess(result.transaction);
      }
    } catch (err: any) {
      setError(err.message || 'Payment failed');
    } finally {
      setProcessing(false);
    }
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-[#00A86B] mb-4" />
        <p className="text-[#6B7280]">Initializing secure payment...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
        <button 
          onClick={onCancel}
          className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h2 className="text-lg font-semibold">Secure Payment</h2>
      </div>

      <div className="flex-1 px-6 py-8">
        {/* Payment Summary */}
        <div className="bg-[#F7F7F7] rounded-3xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-[#6B7280]">You pay</p>
              <p className="text-2xl font-bold">${paymentDetails?.amount?.toFixed(2)}</p>
            </div>
          </div>
          
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-[#6B7280]">Amount to send</span>
              <span className="font-medium">${amount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6B7280]">Fee</span>
              <span className="font-medium">${paymentDetails?.fee?.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Security Badge */}
        <div className="flex items-center justify-center gap-2 mb-6 text-sm text-[#6B7280]">
          <Lock className="w-4 h-4" />
          <span>Secured by Stripe</span>
        </div>

        {/* Card Form */}
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label className="text-sm font-medium text-[#6B7280] mb-2 block">
              Card Information
            </label>
            <div 
              id="card-element" 
              className="p-4 border-2 border-[#E5E5E5] rounded-2xl focus-within:border-[#00A86B] transition-colors"
            />
          </div>

          {error && (
            <div className="mb-4 p-4 bg-red-50 rounded-2xl text-red-600 text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={processing || !stripe}
            className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {processing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <CreditCard className="w-5 h-5" />
                Pay ${paymentDetails?.amount?.toFixed(2)}
              </>
            )}
          </button>
        </form>

        {/* Trust Badges */}
        <div className="mt-8 flex items-center justify-center gap-4 text-xs text-[#6B7280]">
          <span className="flex items-center gap-1">
            <Lock className="w-3 h-3" />
            SSL Encrypted
          </span>
          <span className="flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            PCI Compliant
          </span>
        </div>
      </div>
    </div>
  );
}
