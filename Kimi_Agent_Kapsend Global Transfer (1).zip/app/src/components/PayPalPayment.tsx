import { useState, useEffect } from 'react';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import { Loader2, ArrowLeft } from 'lucide-react';

interface PayPalPaymentProps {
  amount: number;
  currency: string;
  paypalEmail: string;
  mobileProvider: string;
  mobileNumber: string;
  onSuccess: (transaction: any) => void;
  onCancel: () => void;
}

export default function PayPalPayment({
  amount,
  currency,
  paypalEmail,
  mobileProvider,
  mobileNumber: _mobileNumber,
  onSuccess,
  onCancel,
}: PayPalPaymentProps) {
  const [loading, setLoading] = useState(true);
  const [clientId, setClientId] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  // PayPal Client ID - NKAPSEND App
  const PAYPAL_CLIENT_ID = 'AZaq801tfmI5t_0zbg0ony-0Lw9g4wg7u53E1YmZpjZHVWtLJIWfTpTP9_YcauuGl9ldg4n6oPyCAGGj';

  useEffect(() => {
    setClientId(PAYPAL_CLIENT_ID);
    setLoading(false);
  }, []);

  async function createOrder() {
    try {
      // Create order directly with PayPal API
      const accessToken = await getPayPalAccessToken();
      
      const response = await fetch('https://api-m.sandbox.paypal.com/v2/checkout/orders', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          intent: 'CAPTURE',
          purchase_units: [{
            amount: {
              currency_code: currency,
              value: (amount * 0.965).toFixed(2), // After 3.5% fee
            },
            description: `Mobile Money to PayPal - ${mobileProvider}`,
            payee: {
              email_address: paypalEmail,
            },
          }],
        }),
      });
      
      const data = await response.json();
      if (data.id) {
        return data.id;
      }
      throw new Error(data.message || 'Failed to create order');
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }

  async function getPayPalAccessToken() {
    const PAYPAL_SECRET = 'EEC9_opqaTNNzPdih1_kqjmDBFsDW0A8Na873DfCMnhPLD-WHMD0Ga14eSGpA4I_jbie-fOfHPNFnlvQ';
    const auth = btoa(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`);
    
    const response = await fetch('https://api-m.sandbox.paypal.com/v1/oauth2/token', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'grant_type=client_credentials',
    });
    
    const data = await response.json();
    return data.access_token;
  }

  async function onApprove(data: any) {
    try {
      // Capture the payment
      const accessToken = await getPayPalAccessToken();
      
      const response = await fetch(`https://api-m.sandbox.paypal.com/v2/checkout/orders/${data.orderID}/capture`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });
      
      const result = await response.json();
      if (result.status === 'COMPLETED') {
        onSuccess({
          id: `TXN${Date.now()}`,
          status: 'completed',
          amount: amount * 0.965,
        });
      } else {
        throw new Error('Payment capture failed');
      }
    } catch (err: any) {
      setError(err.message);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#00A86B] mb-4" />
        <p className="text-[#6B7280]">Loading PayPal...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center px-6">
        <div className="text-center">
          <p className="text-red-600 mb-4">{error}</p>
          <button onClick={onCancel} className="btn-primary">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
        <button 
          onClick={onCancel}
          className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h2 className="text-lg font-semibold">Pay with PayPal</h2>
      </div>

      <div className="flex-1 px-6 py-8">
        {/* Summary */}
        <div className="bg-[#F7F7F7] rounded-3xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-[#6B7280]">You send (Mobile Money)</p>
              <p className="text-2xl font-bold">${amount.toFixed(2)}</p>
              <p className="text-xs text-[#6B7280]">via {mobileProvider}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 my-4">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <span className="text-blue-600 text-lg">→</span>
            </div>
            <div className="flex-1 h-px bg-[#E5E5E5]"></div>
          </div>
          
          <div>
            <p className="text-sm text-[#6B7280]">You receive</p>
            <p className="text-2xl font-bold text-blue-600">${(amount * 0.965).toFixed(2)} USD</p>
            <p className="text-xs text-[#6B7280]">to {paypalEmail}</p>
          </div>
          
          <div className="mt-4 pt-4 border-t border-[#E5E5E5] text-sm">
            <div className="flex justify-between">
              <span className="text-[#6B7280]">Conversion fee (3.5%)</span>
              <span className="font-medium">${(amount * 0.035).toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* PayPal Buttons */}
        {clientId && (
          <PayPalScriptProvider
            options={{
              clientId: clientId,
              currency: currency,
              intent: 'capture',
            }}
          >
            <PayPalButtons
              createOrder={createOrder}
              onApprove={onApprove}
              onCancel={() => onCancel()}
              onError={(err: any) => setError(err.message || 'PayPal error')}
              style={{
                layout: 'vertical',
                color: 'gold',
                shape: 'rect',
                label: 'pay',
              }}
            />
          </PayPalScriptProvider>
        )}

        <p className="text-center text-xs text-[#6B7280] mt-6">
          Secured by PayPal. You'll be redirected to PayPal to complete the payment.
        </p>
      </div>
    </div>
  );
}
