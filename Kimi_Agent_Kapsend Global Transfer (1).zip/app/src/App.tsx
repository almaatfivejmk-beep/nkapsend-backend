import { useState } from 'react';
import { 
  ChevronLeft, 
  Search, 
  X,
  ArrowRight,
  Shield,
  Clock,
  CheckCircle2,
  Wallet,
  Zap,
  ChevronDown,
  User,
  Receipt,
  Droplets,
  Zap as ZapIcon,
  Smartphone,
  Wifi,
  Tv,
  Flame,
  Globe,
  MapPin,
  RefreshCw,
  CreditCard,
  History,
  ArrowUpRight,
  ArrowDownLeft
} from 'lucide-react';
import './App.css';
import StripePayment from './components/StripePayment';
import PayPalPayment from './components/PayPalPayment';

// All 54 African countries
const africanCountries = [
  { code: 'DZ', name: 'Algeria', flag: '🇩🇿', currency: 'DZD' },
  { code: 'AO', name: 'Angola', flag: '🇦🇴', currency: 'AOA' },
  { code: 'BJ', name: 'Benin', flag: '🇧🇯', currency: 'XOF' },
  { code: 'BW', name: 'Botswana', flag: '🇧🇼', currency: 'BWP' },
  { code: 'BF', name: 'Burkina Faso', flag: '🇧🇫', currency: 'XOF' },
  { code: 'BI', name: 'Burundi', flag: '🇧🇮', currency: 'BIF' },
  { code: 'CM', name: 'Cameroon', flag: '🇨🇲', currency: 'XAF' },
  { code: 'CV', name: 'Cape Verde', flag: '🇨🇻', currency: 'CVE' },
  { code: 'CF', name: 'Central African Republic', flag: '🇨🇫', currency: 'XAF' },
  { code: 'TD', name: 'Chad', flag: '🇹🇩', currency: 'XAF' },
  { code: 'KM', name: 'Comoros', flag: '🇰🇲', currency: 'KMF' },
  { code: 'CG', name: 'Congo', flag: '🇨🇬', currency: 'XAF' },
  { code: 'CD', name: 'DR Congo', flag: '🇨🇩', currency: 'CDF' },
  { code: 'CI', name: "Côte d'Ivoire", flag: '🇨🇮', currency: 'XOF' },
  { code: 'DJ', name: 'Djibouti', flag: '🇩🇯', currency: 'DJF' },
  { code: 'EG', name: 'Egypt', flag: '🇪🇬', currency: 'EGP' },
  { code: 'GQ', name: 'Equatorial Guinea', flag: '🇬🇶', currency: 'XAF' },
  { code: 'ER', name: 'Eritrea', flag: '🇪🇷', currency: 'ERN' },
  { code: 'SZ', name: 'Eswatini', flag: '🇸🇿', currency: 'SZL' },
  { code: 'ET', name: 'Ethiopia', flag: '🇪🇹', currency: 'ETB' },
  { code: 'GA', name: 'Gabon', flag: '🇬🇦', currency: 'XAF' },
  { code: 'GM', name: 'Gambia', flag: '🇬🇲', currency: 'GMD' },
  { code: 'GH', name: 'Ghana', flag: '🇬🇭', currency: 'GHS' },
  { code: 'GN', name: 'Guinea', flag: '🇬🇳', currency: 'GNF' },
  { code: 'GW', name: 'Guinea-Bissau', flag: '🇬🇼', currency: 'XOF' },
  { code: 'KE', name: 'Kenya', flag: '🇰🇪', currency: 'KES' },
  { code: 'LS', name: 'Lesotho', flag: '🇱🇸', currency: 'LSL' },
  { code: 'LR', name: 'Liberia', flag: '🇱🇷', currency: 'LRD' },
  { code: 'LY', name: 'Libya', flag: '🇱🇾', currency: 'LYD' },
  { code: 'MG', name: 'Madagascar', flag: '🇲🇬', currency: 'MGA' },
  { code: 'MW', name: 'Malawi', flag: '🇲🇼', currency: 'MWK' },
  { code: 'ML', name: 'Mali', flag: '🇲🇱', currency: 'XOF' },
  { code: 'MR', name: 'Mauritania', flag: '🇲🇷', currency: 'MRU' },
  { code: 'MU', name: 'Mauritius', flag: '🇲🇺', currency: 'MUR' },
  { code: 'MA', name: 'Morocco', flag: '🇲🇦', currency: 'MAD' },
  { code: 'MZ', name: 'Mozambique', flag: '🇲🇿', currency: 'MZN' },
  { code: 'NA', name: 'Namibia', flag: '🇳🇦', currency: 'NAD' },
  { code: 'NE', name: 'Niger', flag: '🇳🇪', currency: 'XOF' },
  { code: 'NG', name: 'Nigeria', flag: '🇳🇬', currency: 'NGN' },
  { code: 'RW', name: 'Rwanda', flag: '🇷🇼', currency: 'RWF' },
  { code: 'ST', name: 'São Tomé', flag: '🇸🇹', currency: 'STN' },
  { code: 'SN', name: 'Senegal', flag: '🇸🇳', currency: 'XOF' },
  { code: 'SC', name: 'Seychelles', flag: '🇸🇨', currency: 'SCR' },
  { code: 'SL', name: 'Sierra Leone', flag: '🇸🇱', currency: 'SLE' },
  { code: 'SO', name: 'Somalia', flag: '🇸🇴', currency: 'SOS' },
  { code: 'ZA', name: 'South Africa', flag: '🇿🇦', currency: 'ZAR' },
  { code: 'SS', name: 'South Sudan', flag: '🇸🇸', currency: 'SSP' },
  { code: 'SD', name: 'Sudan', flag: '🇸🇩', currency: 'SDG' },
  { code: 'TZ', name: 'Tanzania', flag: '🇹🇿', currency: 'TZS' },
  { code: 'TG', name: 'Togo', flag: '🇹🇬', currency: 'XOF' },
  { code: 'TN', name: 'Tunisia', flag: '🇹🇳', currency: 'TND' },
  { code: 'UG', name: 'Uganda', flag: '🇺🇬', currency: 'UGX' },
  { code: 'ZM', name: 'Zambia', flag: '🇿🇲', currency: 'ZMW' },
  { code: 'ZW', name: 'Zimbabwe', flag: '🇿🇼', currency: 'ZWL' },
];

// Worldwide countries
const worldwideCountries = [
  // Africa
  ...africanCountries,
  // North America
  { code: 'US', name: 'United States', flag: '🇺🇸', currency: 'USD' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦', currency: 'CAD' },
  { code: 'MX', name: 'Mexico', flag: '🇲🇽', currency: 'MXN' },
  // Europe
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', currency: 'GBP' },
  { code: 'FR', name: 'France', flag: '🇫🇷', currency: 'EUR' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪', currency: 'EUR' },
  { code: 'IT', name: 'Italy', flag: '🇮🇹', currency: 'EUR' },
  { code: 'ES', name: 'Spain', flag: '🇪🇸', currency: 'EUR' },
  { code: 'PT', name: 'Portugal', flag: '🇵🇹', currency: 'EUR' },
  { code: 'NL', name: 'Netherlands', flag: '🇳🇱', currency: 'EUR' },
  { code: 'BE', name: 'Belgium', flag: '🇧🇪', currency: 'EUR' },
  { code: 'CH', name: 'Switzerland', flag: '🇨🇭', currency: 'CHF' },
  { code: 'AT', name: 'Austria', flag: '🇦🇹', currency: 'EUR' },
  { code: 'SE', name: 'Sweden', flag: '🇸🇪', currency: 'SEK' },
  { code: 'NO', name: 'Norway', flag: '🇳🇴', currency: 'NOK' },
  { code: 'DK', name: 'Denmark', flag: '🇩🇰', currency: 'DKK' },
  { code: 'PL', name: 'Poland', flag: '🇵🇱', currency: 'PLN' },
  { code: 'IE', name: 'Ireland', flag: '🇮🇪', currency: 'EUR' },
  // Asia
  { code: 'CN', name: 'China', flag: '🇨🇳', currency: 'CNY' },
  { code: 'JP', name: 'Japan', flag: '🇯🇵', currency: 'JPY' },
  { code: 'IN', name: 'India', flag: '🇮🇳', currency: 'INR' },
  { code: 'KR', name: 'South Korea', flag: '🇰🇷', currency: 'KRW' },
  { code: 'SG', name: 'Singapore', flag: '🇸🇬', currency: 'SGD' },
  { code: 'TH', name: 'Thailand', flag: '🇹🇭', currency: 'THB' },
  { code: 'MY', name: 'Malaysia', flag: '🇲🇾', currency: 'MYR' },
  { code: 'ID', name: 'Indonesia', flag: '🇮🇩', currency: 'IDR' },
  { code: 'PH', name: 'Philippines', flag: '🇵🇭', currency: 'PHP' },
  { code: 'VN', name: 'Vietnam', flag: '🇻🇳', currency: 'VND' },
  { code: 'AE', name: 'UAE', flag: '🇦🇪', currency: 'AED' },
  { code: 'SA', name: 'Saudi Arabia', flag: '🇸🇦', currency: 'SAR' },
  { code: 'TR', name: 'Turkey', flag: '🇹🇷', currency: 'TRY' },
  { code: 'IL', name: 'Israel', flag: '🇮🇱', currency: 'ILS' },
  // Oceania
  { code: 'AU', name: 'Australia', flag: '🇦🇺', currency: 'AUD' },
  { code: 'NZ', name: 'New Zealand', flag: '🇳🇿', currency: 'NZD' },
  // South America
  { code: 'BR', name: 'Brazil', flag: '🇧🇷', currency: 'BRL' },
  { code: 'AR', name: 'Argentina', flag: '🇦🇷', currency: 'ARS' },
  { code: 'CL', name: 'Chile', flag: '🇨🇱', currency: 'CLP' },
  { code: 'CO', name: 'Colombia', flag: '🇨🇴', currency: 'COP' },
  { code: 'PE', name: 'Peru', flag: '🇵🇪', currency: 'PEN' },
  // Caribbean
  { code: 'JM', name: 'Jamaica', flag: '🇯🇲', currency: 'JMD' },
  { code: 'HT', name: 'Haiti', flag: '🇭🇹', currency: 'HTG' },
  { code: 'TT', name: 'Trinidad & Tobago', flag: '🇹🇹', currency: 'TTD' },
  { code: 'BB', name: 'Barbados', flag: '🇧🇧', currency: 'BBD' },
  { code: 'GY', name: 'Guyana', flag: '🇬🇾', currency: 'GYD' },
];

// Popular countries
const popularCountries = ['Nigeria', 'Ghana', 'Kenya', 'Cameroon', 'United States', 'United Kingdom', 'Canada', 'India', 'France'];

// Bill types
const billTypes = [
  { id: 'water', name: 'Water', icon: Droplets, color: '#3B82F6' },
  { id: 'electricity', name: 'Electricity', icon: ZapIcon, color: '#F59E0B' },
  { id: 'phone', name: 'Phone/Airtime', icon: Smartphone, color: '#10B981' },
  { id: 'data', name: 'Internet/Data', icon: Wifi, color: '#8B5CF6' },
  { id: 'tv', name: 'Cable TV', icon: Tv, color: '#EC4899' },
  { id: 'gas', name: 'Gas', icon: Flame, color: '#EF4444' },
];

// Mobile Money Providers by Country
const mobileMoneyProviders: Record<string, string[]> = {
  'Nigeria': ['OPay', 'PalmPay', 'Kuda', 'Moniepoint'],
  'Ghana': ['MTN MoMo', 'Vodafone Cash', 'AirtelTigo Money'],
  'Kenya': ['M-Pesa', 'Airtel Money', 'T-Kash'],
  'Uganda': ['MTN Mobile Money', 'Airtel Money'],
  'Tanzania': ['M-Pesa Tanzania', 'Tigo Pesa', 'Airtel Money'],
  'Cameroon': ['MTN Mobile Money', 'Orange Money'],
  'Rwanda': ['MTN Mobile Money', 'Airtel Money'],
  'Zambia': ['MTN Mobile Money', 'Airtel Money'],
  'Zimbabwe': ['EcoCash', 'OneMoney', 'Telecash'],
  'South Africa': ['Vodapay', 'MTN MoMo'],
  'Ivory Coast': ['Orange Money', 'MTN Mobile Money', 'Wave'],
  'Senegal': ['Orange Money', 'Wave', 'Free Money'],
  'Mali': ['Orange Money', 'MTN Mobile Money'],
  'Burkina Faso': ['Orange Money', 'MTN Mobile Money'],
  'Niger': ['Orange Money', 'Airtel Money'],
  'Benin': ['MTN Mobile Money', 'Moov Money'],
  'Togo': ['TMoney', 'Moov Money'],
  'Gabon': ['Airtel Money', 'Libertis'],
  'Congo': ['Airtel Money', 'MTN Mobile Money'],
  'DR Congo': ['M-Pesa', 'Airtel Money', 'Orange Money'],
  'Ethiopia': ['Telebirr', 'Amole'],
  'Egypt': ['Vodafone Cash Egypt', 'Etisalat Cash', 'Orange Cash'],
  'Morocco': ['Inwi Money', 'Orange Money Morocco'],
  'Tunisia': ['D17', 'Floussy'],
  'Algeria': ['Bimpli', 'Mobimoney'],
};

// Payment Methods by Country (for receiving money)
const paymentMethodsByCountry: Record<string, { id: string; name: string; icon: string; color: string }[]> = {
  'United States': [
    { id: 'cashapp', name: 'Cash App', icon: '$', color: '#00D632' },
    { id: 'zelle', name: 'Zelle', icon: 'Z', color: '#6B1CB5' },
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'venmo', name: 'Venmo', icon: 'V', color: '#008CFF' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
  ],
  'United Kingdom': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'revolut', name: 'Revolut', icon: 'R', color: '#0075EB' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
  ],
  'Canada': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'interac', name: 'Interac', icon: 'I', color: '#FDB913' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
  ],
  'Nigeria': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
    { id: 'mobilemoney', name: 'Mobile Money', icon: '📱', color: '#00A86B' },
  ],
  'Ghana': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
    { id: 'mobilemoney', name: 'Mobile Money', icon: '📱', color: '#00A86B' },
  ],
  'Kenya': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
    { id: 'mobilemoney', name: 'M-Pesa', icon: '📱', color: '#00A86B' },
  ],
  'South Africa': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
    { id: 'mobilemoney', name: 'Mobile Money', icon: '📱', color: '#00A86B' },
  ],
  'Uganda': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
    { id: 'mobilemoney', name: 'Mobile Money', icon: '📱', color: '#00A86B' },
  ],
  'Tanzania': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
    { id: 'mobilemoney', name: 'Mobile Money', icon: '📱', color: '#00A86B' },
  ],
  'Cameroon': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
    { id: 'mobilemoney', name: 'Mobile Money', icon: '📱', color: '#00A86B' },
  ],
  'India': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'upi', name: 'UPI', icon: 'U', color: '#4B0082' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
  ],
  'Australia': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'payid', name: 'PayID', icon: 'P', color: '#FF6B35' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
  ],
  'default': [
    { id: 'paypal', name: 'PayPal', icon: 'P', color: '#003087' },
    { id: 'wise', name: 'Wise', icon: 'W', color: '#9FE870' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦', color: '#6B7280' },
  ],
};

// Bill providers by country
const billProviders: Record<string, Record<string, string[]>> = {
  'Nigeria': {
    water: ['Lagos Water Corporation', 'FCT Water Board', 'Port Harcourt Water'],
    electricity: ['Ikeja Electric', 'Eko Electricity', 'Abuja Disco', 'Ibadan Disco', 'Enugu Disco', 'PHED', 'Kano Disco'],
    phone: ['MTN Nigeria', 'Airtel Nigeria', 'Glo Nigeria', '9mobile'],
    data: ['MTN Data', 'Airtel Data', 'Glo Data', '9mobile Data'],
    tv: ['DStv Nigeria', 'GOtv Nigeria', 'StarTimes Nigeria', 'Showmax'],
    gas: ['Shell Gas Nigeria', 'Total Gas Nigeria', 'Nigeria LNG'],
  },
  'Cameroon': {
    water: ['CAMWATER', 'SNEC'],
    electricity: ['ENEO', 'ENEO Prepaid'],
    phone: ['MTN Cameroon', 'Orange Cameroon', 'Nexttel'],
    data: ['MTN Cameroon Data', 'Orange Cameroon Data', 'Nexttel Data'],
    tv: ['Canal+ Cameroon', 'DStv Cameroon', 'Startimes Cameroon'],
    gas: ['Total Gas Cameroon', 'Tradex Gas'],
  },
  'Ghana': {
    water: ['Ghana Water Company', 'Aqua Africa'],
    electricity: ['ECG', 'NEDCo'],
    phone: ['MTN Ghana', 'Vodafone Ghana', 'AirtelTigo'],
    data: ['MTN Ghana Data', 'Vodafone Data', 'AirtelTigo Data'],
    tv: ['DStv Ghana', 'GOtv Ghana', 'StarTimes Ghana'],
    gas: ['Shell Gas Ghana', 'Total Gas Ghana'],
  },
  'Kenya': {
    water: ['Nairobi City Water', 'Mombasa Water', 'Nakuru Water'],
    electricity: ['Kenya Power', 'KPLC'],
    phone: ['Safaricom', 'Airtel Kenya', 'Telkom Kenya'],
    data: ['Safaricom Data', 'Airtel Kenya Data', 'Telkom Data'],
    tv: ['DStv Kenya', 'GOtv Kenya', 'Zuku TV', 'StarTimes Kenya'],
    gas: ['Hashi Energy', 'Total Gas Kenya'],
  },
  'Uganda': {
    water: ['National Water', 'NWSC'],
    electricity: ['UMEME', 'UEDCL'],
    phone: ['MTN Uganda', 'Airtel Uganda'],
    data: ['MTN Uganda Data', 'Airtel Uganda Data'],
    tv: ['DStv Uganda', 'GOtv Uganda', 'StarTimes Uganda'],
    gas: ['Shell Gas Uganda', 'Total Gas Uganda'],
  },
  'Tanzania': {
    water: ['DAWASA', 'Maji Tech'],
    electricity: ['TANESCO', 'TANESCO Prepaid'],
    phone: ['Vodacom Tanzania', 'Airtel Tanzania', 'Tigo Tanzania', 'Halotel'],
    data: ['Vodacom Data', 'Airtel Tanzania Data', 'Tigo Data'],
    tv: ['DStv Tanzania', 'GOtv Tanzania', 'Zuku Tanzania'],
    gas: ['Oryx Gas', 'Total Gas Tanzania'],
  },
  'South Africa': {
    water: ['Johannesburg Water', 'Cape Town Water', 'eThekwini Water'],
    electricity: ['Eskom', 'City Power', 'Cape Town Electricity'],
    phone: ['Vodacom SA', 'MTN SA', 'Cell C', 'Telkom Mobile'],
    data: ['Vodacom Data', 'MTN SA Data', 'Cell C Data'],
    tv: ['DStv SA', 'Openview', 'StarSat'],
    gas: ['Egoli Gas', 'Sasol Gas'],
  },
  'United States': {
    water: ['American Water', 'Aqua America'],
    electricity: ['Con Edison', 'PG&E', 'Duke Energy', 'Florida Power'],
    phone: ['Verizon', 'AT&T', 'T-Mobile', 'Sprint'],
    data: ['Verizon Data', 'AT&T Data', 'T-Mobile Data'],
    tv: ['Xfinity', 'Spectrum', 'DirecTV', 'Dish Network'],
    gas: ['National Grid', 'Con Edison Gas'],
  },
  'United Kingdom': {
    water: ['Thames Water', 'Severn Trent', 'United Utilities'],
    electricity: ['British Gas', 'EDF Energy', 'E.ON', 'OVO Energy'],
    phone: ['EE', 'O2', 'Vodafone UK', 'Three'],
    data: ['EE Data', 'O2 Data', 'Vodafone Data'],
    tv: ['Sky', 'Virgin Media', 'BT TV', 'TalkTalk TV'],
    gas: ['British Gas', 'EDF Gas', 'E.ON Gas'],
  },
  'India': {
    water: ['Delhi Jal Board', 'Mumbai Water', 'Bangalore Water'],
    electricity: ['Tata Power', 'Adani Electricity', 'BESCOM', 'MSEB'],
    phone: ['Jio', 'Airtel India', 'Vi', 'BSNL'],
    data: ['Jio Data', 'Airtel India Data', 'Vi Data'],
    tv: ['Tata Play', 'Dish TV', 'Airtel DTH', 'Sun Direct'],
    gas: ['Indraprastha Gas', 'Mahanagar Gas'],
  },
};

function App() {
  const [screen, setScreen] = useState<'welcome' | 'send-country' | 'receive-country' | 'amount' | 'recipient' | 'review' | 'success' | 'bills' | 'bill-country' | 'bill-payment' | 'paypal-country' | 'paypal-amount' | 'paypal-review' | 'paypal-success' | 'payment-method' | 'history' | 'stripe-payment' | 'paypal-checkout'>('welcome');
  const [sendCountry, setSendCountry] = useState(worldwideCountries.find(c => c.name === 'United States') || worldwideCountries[0]);
  const [receiveCountry, setReceiveCountry] = useState(worldwideCountries.find(c => c.name === 'Nigeria') || worldwideCountries[1]);
  const [billCountry, setBillCountry] = useState(worldwideCountries.find(c => c.name === 'Nigeria') || worldwideCountries[0]);
  const [paypalCountry, setPaypalCountry] = useState(africanCountries.find(c => c.name === 'Nigeria') || africanCountries[0]);
  const [amount, setAmount] = useState('');
  const [recipient, setRecipient] = useState({ name: '', phone: '', paymentMethod: '', paymentId: '' });
  const [paypalEmail, setPaypalEmail] = useState('');
  const [selectedProvider, setSelectedProvider] = useState('');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<{ id: string; name: string; icon: string; color: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'send' | 'bills' | 'paypal'>('send');
  const [selectedBillType, setSelectedBillType] = useState<typeof billTypes[0] | null>(null);
  const [billDetails, setBillDetails] = useState({ accountNumber: '', provider: '' });
  const [historyFilter, setHistoryFilter] = useState<'all' | 'sent' | 'received'>('all');

  // Sample transaction history data
  const [transactions] = useState([
    { id: 'TXN001', type: 'sent', name: 'John Doe', country: 'Nigeria', amount: 500, currency: 'USD', date: '2024-03-11', status: 'completed', paymentMethod: 'Bank Transfer' },
    { id: 'TXN002', type: 'received', name: 'Sarah Smith', country: 'United States', amount: 250, currency: 'USD', date: '2024-03-10', status: 'completed', paymentMethod: 'PayPal' },
    { id: 'TXN003', type: 'sent', name: 'Michael Johnson', country: 'Ghana', amount: 300, currency: 'USD', date: '2024-03-09', status: 'completed', paymentMethod: 'Mobile Money' },
    { id: 'TXN004', type: 'sent', name: 'ENEO Cameroon', country: 'Cameroon', amount: 75, currency: 'USD', date: '2024-03-08', status: 'completed', paymentMethod: 'Bill Payment' },
    { id: 'TXN005', type: 'received', name: 'Emma Wilson', country: 'United Kingdom', amount: 150, currency: 'USD', date: '2024-03-07', status: 'completed', paymentMethod: 'Wise' },
    { id: 'TXN006', type: 'sent', name: 'David Brown', country: 'Kenya', amount: 200, currency: 'USD', date: '2024-03-06', status: 'pending', paymentMethod: 'M-Pesa' },
    { id: 'TXN007', type: 'sent', name: 'Amina Hassan', country: 'Tanzania', amount: 180, currency: 'USD', date: '2024-03-05', status: 'completed', paymentMethod: 'Mobile Money' },
    { id: 'TXN008', type: 'received', name: 'James Miller', country: 'Canada', amount: 400, currency: 'USD', date: '2024-03-04', status: 'completed', paymentMethod: 'Interac' },
  ]);

  // Exchange rates (simplified)
  const getExchangeRate = (from: string, to: string) => {
    const rates: Record<string, number> = {
      'USD-NGN': 1550,
      'USD-GHS': 15.5,
      'USD-KES': 130,
      'USD-UGX': 3700,
      'USD-TZS': 2600,
      'USD-XOF': 605,
      'USD-XAF': 605,
      'USD-ZAR': 18.5,
      'USD-EGP': 48.5,
      'USD-MAD': 10.1,
      'USD-TND': 3.1,
      'USD-GBP': 0.79,
      'USD-EUR': 0.92,
      'USD-CAD': 1.36,
      'USD-AUD': 1.52,
      'USD-INR': 83.5,
      'USD-PKR': 278,
      'USD-BDT': 109.5,
      'USD-PHP': 56.2,
      'USD-IDR': 15800,
      'USD-MYR': 4.75,
      'USD-THB': 35.8,
      'USD-SGD': 1.34,
      'USD-JPY': 150,
      'USD-CNY': 7.2,
      'USD-BRL': 4.95,
      'USD-MXN': 17.1,
    };
    return rates[`${from}-${to}`] || Math.random() * 100 + 10;
  };

  // Mobile money to USD conversion rates
  const getMobileMoneyRate = (currency: string) => {
    const rates: Record<string, number> = {
      'NGN': 1550,
      'GHS': 15.5,
      'KES': 130,
      'UGX': 3700,
      'TZS': 2600,
      'XOF': 605,
      'XAF': 605,
      'ZAR': 18.5,
      'EGP': 48.5,
      'MAD': 10.1,
      'TND': 3.1,
      'RWF': 1300,
      'ZMW': 25,
      'BWP': 13.5,
      'NAD': 18.5,
      'SZL': 18.5,
      'LSL': 18.5,
      'MWK': 1700,
      'BIF': 2800,
      'DJF': 177,
      'ERN': 15,
      'ETB': 55,
      'GMD': 67,
      'GNF': 8500,
      'LRD': 190,
      'LYD': 4.8,
      'MGA': 4500,
      'MRU': 39,
      'MUR': 45,
      'MZN': 63,
      'SCR': 13.5,
      'SDG': 600,
      'SOS': 570,
      'SSP': 130,
      'STN': 22,
      'CVE': 100,
      'KMF': 450,
      'AOA': 830,
      'CDF': 2700,
      'DZD': 134,
      'GIP': 0.79,
      'SLL': 21000,
    };
    return rates[currency] || 100;
  };

  const calculatePaypalAmount = () => {
    const numAmount = parseFloat(amount) || 0;
    const rate = getMobileMoneyRate(paypalCountry.currency);
    const fee = numAmount * 0.035; // 3.5% conversion fee
    return ((numAmount - fee) / rate).toFixed(2);
  };

  const calculateReceiveAmount = () => {
    const numAmount = parseFloat(amount) || 0;
    const rate = getExchangeRate(sendCountry.currency, receiveCountry.currency);
    return (numAmount * rate).toLocaleString('en-US', { maximumFractionDigits: 0 });
  };

  const filteredCountries = worldwideCountries.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredAfricanCountries = africanCountries.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const popularList = worldwideCountries.filter(c => popularCountries.includes(c.name));
  const otherList = filteredCountries.filter(c => !popularCountries.includes(c.name));

  const popularAfricanList = africanCountries.filter(c => popularCountries.includes(c.name));
  const otherAfricanList = filteredAfricanCountries.filter(c => !popularCountries.includes(c.name));

  // Get providers for selected country and bill type
  const getProviders = () => {
    if (!selectedBillType || !billCountry) return [];
    const countryProviders = billProviders[billCountry.name];
    if (!countryProviders) return [];
    return countryProviders[selectedBillType.id] || [];
  };

  // Get mobile money providers for selected country
  const getMobileMoneyProviders = () => {
    return mobileMoneyProviders[paypalCountry.name] || ['Mobile Money'];
  };

  // Get payment methods for selected country
  const getPaymentMethods = () => {
    return paymentMethodsByCountry[receiveCountry.name] || paymentMethodsByCountry['default'];
  };

  // Welcome Screen
  if (screen === 'welcome') {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="bg-[#00A86B] text-white px-6 pt-12 pb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10"></div>
            <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-[#00A86B] font-bold text-2xl">K</span>
            </div>
            <button 
              onClick={() => setScreen('history')}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <History className="w-5 h-5 text-white" />
            </button>
          </div>
          <h1 className="text-2xl font-bold text-center mb-1">NKAPSEND</h1>
          <p className="text-center text-white/80 text-sm">Send money worldwide & pay bills</p>
        </div>

        {/* Tabs */}
        <div className="flex px-4 py-4 gap-2 border-b border-[#E5E5E5] overflow-x-auto">
          <button
            onClick={() => setActiveTab('send')}
            className={`flex-shrink-0 py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
              activeTab === 'send' 
                ? 'bg-[#00A86B] text-white' 
                : 'bg-[#F7F7F7] text-[#6B7280]'
            }`}
          >
            <Globe className="w-4 h-4" />
            Send Money
          </button>
          <button
            onClick={() => setActiveTab('bills')}
            className={`flex-shrink-0 py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
              activeTab === 'bills' 
                ? 'bg-[#00A86B] text-white' 
                : 'bg-[#F7F7F7] text-[#6B7280]'
            }`}
          >
            <Receipt className="w-4 h-4" />
            Pay Bills
          </button>
          <button
            onClick={() => setActiveTab('paypal')}
            className={`flex-shrink-0 py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
              activeTab === 'paypal' 
                ? 'bg-[#00A86B] text-white' 
                : 'bg-[#F7F7F7] text-[#6B7280]'
            }`}
          >
            <RefreshCw className="w-4 h-4" />
            To PayPal
          </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 px-6 py-6">
          {activeTab === 'send' ? (
            <>
              {/* Quick Send Card */}
              <div className="bg-[#F7F7F7] rounded-3xl p-5 mb-6">
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{sendCountry.flag}</span>
                    <div>
                      <p className="text-xs text-[#6B7280]">You send from</p>
                      <p className="font-semibold text-sm">{sendCountry.name}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setScreen('send-country')}
                    className="text-[#00A86B] font-medium text-xs"
                  >
                    Change
                  </button>
                </div>

                <div className="flex items-center justify-center my-3">
                  <div className="w-8 h-8 bg-[#00A86B]/10 rounded-full flex items-center justify-center">
                    <ArrowRight className="w-4 h-4 text-[#00A86B]" />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{receiveCountry.flag}</span>
                    <div>
                      <p className="text-xs text-[#6B7280]">They receive in</p>
                      <p className="font-semibold text-sm">{receiveCountry.name}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setScreen('receive-country')}
                    className="text-[#00A86B] font-medium text-xs"
                  >
                    Change
                  </button>
                </div>
              </div>

              {/* CTA */}
              <button 
                onClick={() => setScreen('amount')}
                className="btn-primary"
              >
                Send Money
              </button>

              {/* Features */}
              <div className="mt-6 grid grid-cols-4 gap-3">
                <div className="text-center">
                  <div className="w-10 h-10 bg-[#00A86B]/10 rounded-xl flex items-center justify-center mx-auto mb-1">
                    <Globe className="w-5 h-5 text-[#00A86B]" />
                  </div>
                  <p className="text-[10px] text-[#6B7280]">Worldwide</p>
                </div>
                <div className="text-center">
                  <div className="w-10 h-10 bg-[#00A86B]/10 rounded-xl flex items-center justify-center mx-auto mb-1">
                    <Zap className="w-5 h-5 text-[#00A86B]" />
                  </div>
                  <p className="text-[10px] text-[#6B7280]">Instant</p>
                </div>
                <div className="text-center">
                  <div className="w-10 h-10 bg-[#00A86B]/10 rounded-xl flex items-center justify-center mx-auto mb-1">
                    <Shield className="w-5 h-5 text-[#00A86B]" />
                  </div>
                  <p className="text-[10px] text-[#6B7280]">Secure</p>
                </div>
                <div className="text-center">
                  <div className="w-10 h-10 bg-[#00A86B]/10 rounded-xl flex items-center justify-center mx-auto mb-1">
                    <Wallet className="w-5 h-5 text-[#00A86B]" />
                  </div>
                  <p className="text-[10px] text-[#6B7280]">Low Fees</p>
                </div>
              </div>
            </>
          ) : activeTab === 'bills' ? (
            /* Bills Section */
            <div className="space-y-4">
              {/* Country Selector for Bills */}
              <div className="bg-[#F7F7F7] rounded-2xl p-4 mb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-[#00A86B]" />
                    <div>
                      <p className="text-xs text-[#6B7280]">Paying bills in</p>
                      <p className="font-semibold">{billCountry.name}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{billCountry.flag}</span>
                    <button 
                      onClick={() => setScreen('bill-country')}
                      className="text-[#00A86B] font-medium text-xs"
                    >
                      Change
                    </button>
                  </div>
                </div>
              </div>

              <p className="text-sm font-medium text-[#6B7280]">Select bill type</p>
              <div className="grid grid-cols-2 gap-3">
                {billTypes.map((bill) => (
                  <button
                    key={bill.id}
                    onClick={() => {
                      setSelectedBillType(bill);
                      setScreen('bill-payment');
                    }}
                    className="bg-[#F7F7F7] rounded-2xl p-4 flex flex-col items-center gap-2 hover:bg-[#00A86B]/5 transition-colors"
                  >
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${bill.color}20` }}
                    >
                      <bill.icon className="w-6 h-6" style={{ color: bill.color }} />
                    </div>
                    <span className="text-sm font-medium">{bill.name}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* PayPal Conversion Section */
            <div className="space-y-4">
              {/* Country Selector for PayPal */}
              <div className="bg-[#F7F7F7] rounded-2xl p-4 mb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Smartphone className="w-5 h-5 text-[#00A86B]" />
                    <div>
                      <p className="text-xs text-[#6B7280]">Mobile Money from</p>
                      <p className="font-semibold">{paypalCountry.name}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{paypalCountry.flag}</span>
                    <button 
                      onClick={() => setScreen('paypal-country')}
                      className="text-[#00A86B] font-medium text-xs"
                    >
                      Change
                    </button>
                  </div>
                </div>
              </div>

              {/* Info Card */}
              <div className="bg-blue-50 rounded-2xl p-4 mb-4">
                <div className="flex items-start gap-3">
                  <CreditCard className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-blue-900">Convert Mobile Money to PayPal</p>
                    <p className="text-xs text-blue-700 mt-1">
                      Send money from your {paypalCountry.name} mobile wallet directly to any PayPal account worldwide.
                    </p>
                  </div>
                </div>
              </div>

              {/* Supported Providers */}
              <div className="mb-4">
                <p className="text-sm font-medium text-[#6B7280] mb-2">Supported Mobile Money</p>
                <div className="flex flex-wrap gap-2">
                  {getMobileMoneyProviders().slice(0, 3).map((provider) => (
                    <span key={provider} className="px-3 py-1 bg-[#F7F7F7] rounded-full text-xs font-medium text-[#6B7280]">
                      {provider}
                    </span>
                  ))}
                </div>
              </div>

              {/* CTA */}
              <button 
                onClick={() => setScreen('paypal-amount')}
                className="btn-primary"
              >
                Convert to PayPal
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#E5E5E5]">
          <div className="flex items-center justify-center gap-6 text-xs text-[#6B7280]">
            <span className="flex items-center gap-1">
              <Shield className="w-3 h-3" />
              Licensed
            </span>
            <span className="flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              Regulated
            </span>
          </div>
        </div>
      </div>
    );
  }

  // History Screen
  if (screen === 'history') {
    const filteredTransactions = transactions.filter(t => {
      if (historyFilter === 'all') return true;
      return t.type === historyFilter;
    });

    const totalSent = transactions.filter(t => t.type === 'sent').reduce((sum, t) => sum + t.amount, 0);
    const totalReceived = transactions.filter(t => t.type === 'received').reduce((sum, t) => sum + t.amount, 0);

    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="bg-[#00A86B] text-white px-6 pt-12 pb-6">
          <div className="flex items-center gap-4 mb-6">
            <button 
              onClick={() => setScreen('welcome')}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h2 className="text-xl font-semibold">Transaction History</h2>
          </div>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/20 rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <ArrowUpRight className="w-5 h-5" />
                <span className="text-sm text-white/80">Total Sent</span>
              </div>
              <p className="text-2xl font-bold">${totalSent.toLocaleString()}</p>
            </div>
            <div className="bg-white/20 rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <ArrowDownLeft className="w-5 h-5" />
                <span className="text-sm text-white/80">Total Received</span>
              </div>
              <p className="text-2xl font-bold">${totalReceived.toLocaleString()}</p>
            </div>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex px-4 py-4 gap-2 border-b border-[#E5E5E5]">
          <button
            onClick={() => setHistoryFilter('all')}
            className={`flex-1 py-2 px-4 rounded-xl font-semibold text-sm transition-all ${
              historyFilter === 'all' 
                ? 'bg-[#00A86B] text-white' 
                : 'bg-[#F7F7F7] text-[#6B7280]'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setHistoryFilter('sent')}
            className={`flex-1 py-2 px-4 rounded-xl font-semibold text-sm transition-all ${
              historyFilter === 'sent' 
                ? 'bg-[#00A86B] text-white' 
                : 'bg-[#F7F7F7] text-[#6B7280]'
            }`}
          >
            Sent
          </button>
          <button
            onClick={() => setHistoryFilter('received')}
            className={`flex-1 py-2 px-4 rounded-xl font-semibold text-sm transition-all ${
              historyFilter === 'received' 
                ? 'bg-[#00A86B] text-white' 
                : 'bg-[#F7F7F7] text-[#6B7280]'
            }`}
          >
            Received
          </button>
        </div>

        {/* Transaction List */}
        <div className="flex-1 overflow-y-auto px-4 py-4">
          <div className="space-y-3">
            {filteredTransactions.map((transaction) => (
              <div 
                key={transaction.id}
                className="bg-[#F7F7F7] rounded-2xl p-4"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      transaction.type === 'sent' 
                        ? 'bg-red-100' 
                        : 'bg-green-100'
                    }`}>
                      {transaction.type === 'sent' ? (
                        <ArrowUpRight className={`w-5 h-5 ${
                          transaction.type === 'sent' ? 'text-red-600' : 'text-green-600'
                        }`} />
                      ) : (
                        <ArrowDownLeft className="w-5 h-5 text-green-600" />
                      )}
                    </div>
                    <div>
                      <p className="font-semibold">{transaction.name}</p>
                      <p className="text-xs text-[#6B7280]">{transaction.country}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${
                      transaction.type === 'sent' ? 'text-red-600' : 'text-green-600'
                    }`}>
                      {transaction.type === 'sent' ? '-' : '+'}${transaction.amount}
                    </p>
                    <p className="text-xs text-[#6B7280]">{transaction.date}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-[#E5E5E5]">
                  <span className="text-xs text-[#6B7280]">{transaction.paymentMethod}</span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    transaction.status === 'completed' 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {transaction.status === 'completed' ? 'Completed' : 'Pending'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // PayPal Country Selection Screen
  if (screen === 'paypal-country') {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('welcome')}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold">Select Your Country</h2>
        </div>

        {/* Search */}
        <div className="px-4 py-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search African country..."
              className="w-full pl-12 pr-10 py-3 bg-[#F7F7F7] rounded-2xl text-base focus:outline-none focus:ring-2 focus:ring-[#00A86B]"
              autoFocus
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2"
              >
                <X className="w-5 h-5 text-[#6B7280]" />
              </button>
            )}
          </div>
        </div>

        {/* Country List */}
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          {!searchQuery && (
            <>
              <p className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider mb-3 px-2">
                Popular
              </p>
              <div className="space-y-2 mb-6">
                {popularAfricanList.map((country) => (
                  <button
                    key={country.code}
                    onClick={() => {
                      setPaypalCountry(country);
                      setScreen('welcome');
                      setSearchQuery('');
                    }}
                    className="country-card w-full"
                  >
                    <span className="text-3xl">{country.flag}</span>
                    <div className="flex-1 text-left">
                      <p className="font-semibold">{country.name}</p>
                      <p className="text-xs text-[#6B7280]">{country.currency}</p>
                    </div>
                    {paypalCountry.code === country.code && (
                      <CheckCircle2 className="w-6 h-6 text-[#00A86B]" />
                    )}
                  </button>
                ))}
              </div>
            </>
          )}

          <p className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider mb-3 px-2">
            {searchQuery ? 'Results' : 'All African Countries'}
          </p>
          <div className="space-y-2">
            {(searchQuery ? filteredAfricanCountries : otherAfricanList).map((country) => (
              <button
                key={country.code}
                onClick={() => {
                  setPaypalCountry(country);
                  setScreen('welcome');
                  setSearchQuery('');
                }}
                className="country-card w-full"
              >
                <span className="text-3xl">{country.flag}</span>
                <div className="flex-1 text-left">
                  <p className="font-semibold">{country.name}</p>
                  <p className="text-xs text-[#6B7280]">{country.currency}</p>
                </div>
                {paypalCountry.code === country.code && (
                  <CheckCircle2 className="w-6 h-6 text-[#00A86B]" />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // PayPal Amount Screen
  if (screen === 'paypal-amount') {
    const providers = getMobileMoneyProviders();
    
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('welcome')}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold">Convert to PayPal</h2>
        </div>

        {/* Main Content */}
        <div className="flex-1 px-6 py-8 flex flex-col">
          {/* Country Display */}
          <div className="flex items-center justify-center gap-2 mb-6">
            <span className="text-2xl">{paypalCountry.flag}</span>
            <span className="font-medium">{paypalCountry.name}</span>
            <ArrowRight className="w-4 h-4 text-[#6B7280] mx-2" />
            <div className="flex items-center gap-2">
              <span className="text-2xl">🇺🇸</span>
              <span className="font-medium">PayPal</span>
            </div>
          </div>

          {/* Mobile Money Provider */}
          <div className="mb-6">
            <label className="text-sm font-medium text-[#6B7280] mb-2 block">Select Mobile Money Provider</label>
            <select
              value={selectedProvider}
              onChange={(e) => setSelectedProvider(e.target.value)}
              className="input-field w-full"
            >
              <option value="">Choose provider</option>
              {providers.map((provider) => (
                <option key={provider} value={provider}>{provider}</option>
              ))}
            </select>
          </div>

          {/* Amount Input */}
          <div className="flex-1 flex flex-col items-center justify-center">
            <p className="text-sm text-[#6B7280] mb-4">You send (Mobile Money)</p>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl text-[#6B7280]">{paypalCountry.currency}</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0"
                className="text-5xl font-bold text-center w-48 bg-transparent focus:outline-none"
                autoFocus
              />
            </div>
            
            {amount && (
              <div className="mt-6 text-center animate-slide-up">
                <p className="text-sm text-[#6B7280] mb-1">You receive in PayPal</p>
                <p className="text-3xl font-bold text-[#00A86B]">
                  ${calculatePaypalAmount()} USD
                </p>
                <div className="mt-3 space-y-1 text-xs text-[#6B7280]">
                  <p>Exchange rate: 1 USD = {paypalCountry.currency} {getMobileMoneyRate(paypalCountry.currency).toLocaleString()}</p>
                  <p>Fee: 3.5%</p>
                </div>
              </div>
            )}
          </div>

          {/* Keypad */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '0', '⌫'].map((key) => (
              <button
                key={key}
                onClick={() => {
                  if (key === '⌫') {
                    setAmount(amount.slice(0, -1));
                  } else if (key === '.' && amount.includes('.')) {
                    return;
                  } else {
                    setAmount(amount + key);
                  }
                }}
                className="py-4 text-2xl font-medium rounded-2xl hover:bg-[#F7F7F7] active:bg-[#E5E5E5] transition-colors"
              >
                {key}
              </button>
            ))}
          </div>

          {/* CTA */}
          <button 
            onClick={() => amount && selectedProvider && setScreen('paypal-review')}
            disabled={!amount || !selectedProvider}
            className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Continue
          </button>
        </div>
      </div>
    );
  }

  // PayPal Review Screen
  if (screen === 'paypal-review') {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('paypal-amount')}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold">Review & Convert</h2>
        </div>

        {/* Main Content */}
        <div className="flex-1 px-6 py-8">
          {/* Amount Card */}
          <div className="bg-[#F7F7F7] rounded-3xl p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-[#6B7280]">You send</p>
                <p className="text-2xl font-bold">{paypalCountry.currency} {amount}</p>
                <p className="text-xs text-[#6B7280] mt-1">via {selectedProvider}</p>
              </div>
              <span className="text-3xl">{paypalCountry.flag}</span>
            </div>

            <div className="flex items-center gap-3 my-4">
              <div className="w-8 h-8 bg-[#00A86B]/10 rounded-full flex items-center justify-center">
                <RefreshCw className="w-4 h-4 text-[#00A86B]" />
              </div>
              <div className="flex-1 h-px bg-[#E5E5E5]"></div>
              <p className="text-xs text-[#6B7280]">Instant</p>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280]">You receive</p>
                <p className="text-2xl font-bold text-[#00A86B]">${calculatePaypalAmount()} USD</p>
                <p className="text-xs text-[#6B7280] mt-1">to PayPal</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-2xl">🇺🇸</span>
              </div>
            </div>
          </div>

          {/* PayPal Email */}
          <div className="mb-6">
            <label className="text-sm font-medium text-[#6B7280] mb-2 block">PayPal Email</label>
            <input
              type="email"
              value={paypalEmail}
              onChange={(e) => setPaypalEmail(e.target.value)}
              placeholder="Enter your PayPal email"
              className="input-field"
            />
          </div>

          {/* Details */}
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-[#6B7280]">Conversion fee</span>
              <span className="font-medium">3.5%</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-[#6B7280]">Exchange rate</span>
              <span className="font-medium">1 USD = {paypalCountry.currency} {getMobileMoneyRate(paypalCountry.currency).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-[#6B7280]">Delivery</span>
              <span className="font-medium flex items-center gap-1">
                <Clock className="w-4 h-4" />
                5-30 minutes
              </span>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="px-6 py-4 border-t border-[#E5E5E5]">
          <button 
            onClick={() => paypalEmail && setScreen('paypal-checkout')}
            disabled={!paypalEmail}
            className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <span className="text-xl">P</span>
            Pay with PayPal
          </button>
          <p className="text-center text-xs text-[#6B7280] mt-3">
            You'll be redirected to PayPal to complete the payment
          </p>
        </div>
      </div>
    );
  }

  // PayPal Checkout Screen
  if (screen === 'paypal-checkout') {
    return (
      <PayPalPayment
        amount={parseFloat(amount) || 0}
        currency="USD"
        paypalEmail={paypalEmail}
        mobileProvider={selectedProvider}
        mobileNumber=""
        onSuccess={(transaction) => {
          console.log('PayPal payment successful:', transaction);
          setScreen('paypal-success');
        }}
        onCancel={() => setScreen('paypal-review')}
      />
    );
  }

  // PayPal Success Screen
  if (screen === 'paypal-success') {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center px-6">
        <div className="text-center">
          <div className="w-24 h-24 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Conversion Successful!</h2>
          <p className="text-[#6B7280] mb-8">
            ${calculatePaypalAmount()} USD has been sent to your PayPal account ({paypalEmail}).
          </p>
          
          <div className="bg-[#F7F7F7] rounded-2xl p-6 mb-8 text-left">
            <div className="flex justify-between mb-3">
              <span className="text-[#6B7280]">Amount sent</span>
              <span className="font-semibold">{paypalCountry.currency} {amount}</span>
            </div>
            <div className="flex justify-between mb-3">
              <span className="text-[#6B7280]">Provider</span>
              <span className="font-semibold">{selectedProvider}</span>
            </div>
            <div className="flex justify-between mb-3">
              <span className="text-[#6B7280]">PayPal email</span>
              <span className="font-semibold">{paypalEmail}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6B7280]">Reference</span>
              <span className="font-semibold">NK{Math.random().toString(36).substr(2, 8).toUpperCase()}</span>
            </div>
          </div>
          
          <button 
            onClick={() => {
              setScreen('welcome');
              setAmount('');
              setPaypalEmail('');
              setSelectedProvider('');
            }}
            className="btn-primary"
          >
            Convert Another
          </button>
        </div>
      </div>
    );
  }

  // Country Selection Screen (for send/receive)
  if (screen === 'send-country' || screen === 'receive-country') {
    const selectingSend = screen === 'send-country';
    
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('welcome')}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold">
            {selectingSend ? 'Send from' : 'Send to'}
          </h2>
        </div>

        {/* Search */}
        <div className="px-4 py-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search country..."
              className="w-full pl-12 pr-10 py-3 bg-[#F7F7F7] rounded-2xl text-base focus:outline-none focus:ring-2 focus:ring-[#00A86B]"
              autoFocus
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2"
              >
                <X className="w-5 h-5 text-[#6B7280]" />
              </button>
            )}
          </div>
        </div>

        {/* Country List */}
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          {!searchQuery && (
            <>
              <p className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider mb-3 px-2">
                Popular
              </p>
              <div className="space-y-2 mb-6">
                {popularList.map((country) => (
                  <button
                    key={country.code}
                    onClick={() => {
                      if (selectingSend) setSendCountry(country);
                      else setReceiveCountry(country);
                      setScreen('welcome');
                      setSearchQuery('');
                    }}
                    className="country-card w-full"
                  >
                    <span className="text-3xl">{country.flag}</span>
                    <div className="flex-1 text-left">
                      <p className="font-semibold">{country.name}</p>
                      <p className="text-xs text-[#6B7280]">{country.currency}</p>
                    </div>
                    {(selectingSend ? sendCountry : receiveCountry).code === country.code && (
                      <CheckCircle2 className="w-6 h-6 text-[#00A86B]" />
                    )}
                  </button>
                ))}
              </div>
            </>
          )}

          <p className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider mb-3 px-2">
            {searchQuery ? 'Results' : 'All Countries'}
          </p>
          <div className="space-y-2">
            {(searchQuery ? filteredCountries : otherList).map((country) => (
              <button
                key={country.code}
                onClick={() => {
                  if (selectingSend) setSendCountry(country);
                  else setReceiveCountry(country);
                  setScreen('welcome');
                  setSearchQuery('');
                }}
                className="country-card w-full"
              >
                <span className="text-3xl">{country.flag}</span>
                <div className="flex-1 text-left">
                  <p className="font-semibold">{country.name}</p>
                  <p className="text-xs text-[#6B7280]">{country.currency}</p>
                </div>
                {(selectingSend ? sendCountry : receiveCountry).code === country.code && (
                  <CheckCircle2 className="w-6 h-6 text-[#00A86B]" />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Bill Country Selection Screen
  if (screen === 'bill-country') {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('welcome')}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold">Select Country for Bills</h2>
        </div>

        {/* Search */}
        <div className="px-4 py-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search country..."
              className="w-full pl-12 pr-10 py-3 bg-[#F7F7F7] rounded-2xl text-base focus:outline-none focus:ring-2 focus:ring-[#00A86B]"
              autoFocus
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2"
              >
                <X className="w-5 h-5 text-[#6B7280]" />
              </button>
            )}
          </div>
        </div>

        {/* Country List */}
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          {!searchQuery && (
            <>
              <p className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider mb-3 px-2">
                Popular
              </p>
              <div className="space-y-2 mb-6">
                {popularList.map((country) => (
                  <button
                    key={country.code}
                    onClick={() => {
                      setBillCountry(country);
                      setScreen('welcome');
                      setSearchQuery('');
                    }}
                    className="country-card w-full"
                  >
                    <span className="text-3xl">{country.flag}</span>
                    <div className="flex-1 text-left">
                      <p className="font-semibold">{country.name}</p>
                      <p className="text-xs text-[#6B7280]">{country.currency}</p>
                    </div>
                    {billCountry.code === country.code && (
                      <CheckCircle2 className="w-6 h-6 text-[#00A86B]" />
                    )}
                  </button>
                ))}
              </div>
            </>
          )}

          <p className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider mb-3 px-2">
            {searchQuery ? 'Results' : 'All Countries'}
          </p>
          <div className="space-y-2">
            {(searchQuery ? filteredCountries : otherList).map((country) => (
              <button
                key={country.code}
                onClick={() => {
                  setBillCountry(country);
                  setScreen('welcome');
                  setSearchQuery('');
                }}
                className="country-card w-full"
              >
                <span className="text-3xl">{country.flag}</span>
                <div className="flex-1 text-left">
                  <p className="font-semibold">{country.name}</p>
                  <p className="text-xs text-[#6B7280]">{country.currency}</p>
                </div>
                {billCountry.code === country.code && (
                  <CheckCircle2 className="w-6 h-6 text-[#00A86B]" />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Amount Screen
  if (screen === 'amount') {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('welcome')}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold">Enter Amount</h2>
        </div>

        {/* Main Content */}
        <div className="flex-1 px-6 py-8 flex flex-col">
          {/* Countries */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <div className="flex items-center gap-2">
              <span className="text-2xl">{sendCountry.flag}</span>
              <span className="font-medium">{sendCountry.currency}</span>
            </div>
            <ArrowRight className="w-5 h-5 text-[#6B7280]" />
            <div className="flex items-center gap-2">
              <span className="text-2xl">{receiveCountry.flag}</span>
              <span className="font-medium">{receiveCountry.currency}</span>
            </div>
          </div>

          {/* Amount Input */}
          <div className="flex-1 flex flex-col items-center justify-center">
            <p className="text-sm text-[#6B7280] mb-4">You send</p>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl text-[#6B7280]">{sendCountry.currency === 'USD' ? '$' : sendCountry.currency}</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0"
                className="text-6xl font-bold text-center w-48 bg-transparent focus:outline-none"
                autoFocus
              />
            </div>
            
            {amount && (
              <div className="mt-6 text-center animate-slide-up">
                <p className="text-sm text-[#6B7280] mb-1">They receive</p>
                <p className="text-3xl font-bold text-[#00A86B]">
                  {receiveCountry.currency} {calculateReceiveAmount()}
                </p>
                <p className="text-xs text-[#6B7280] mt-2">
                  Exchange rate: 1 {sendCountry.currency} = {receiveCountry.currency} {getExchangeRate(sendCountry.currency, receiveCountry.currency).toLocaleString()}
                </p>
              </div>
            )}
          </div>

          {/* Keypad */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '0', '⌫'].map((key) => (
              <button
                key={key}
                onClick={() => {
                  if (key === '⌫') {
                    setAmount(amount.slice(0, -1));
                  } else if (key === '.' && amount.includes('.')) {
                    return;
                  } else {
                    setAmount(amount + key);
                  }
                }}
                className="py-4 text-2xl font-medium rounded-2xl hover:bg-[#F7F7F7] active:bg-[#E5E5E5] transition-colors"
              >
                {key}
              </button>
            ))}
          </div>

          {/* CTA */}
          <button 
            onClick={() => amount && setScreen('recipient')}
            disabled={!amount}
            className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Continue
          </button>
        </div>
      </div>
    );
  }

  // Recipient Screen
  if (screen === 'recipient') {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('amount')}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold">Recipient</h2>
        </div>

        {/* Main Content */}
        <div className="flex-1 px-6 py-8">
          <div className="mb-6">
            <p className="text-sm text-[#6B7280] mb-2">Sending to {receiveCountry.name}</p>
            <div className="flex items-center gap-2">
              <span className="text-2xl">{receiveCountry.flag}</span>
              <span className="font-semibold text-lg">{receiveCountry.currency} {calculateReceiveAmount()}</span>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-[#6B7280] mb-2 block">Full Name</label>
              <input
                type="text"
                value={recipient.name}
                onChange={(e) => setRecipient({ ...recipient, name: e.target.value })}
                placeholder="Enter recipient's name"
                className="input-field"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-[#6B7280] mb-2 block">Phone Number</label>
              <div className="flex gap-3">
                <div className="px-4 py-4 bg-[#F7F7F7] rounded-2xl flex items-center gap-2">
                  <span className="text-xl">{receiveCountry.flag}</span>
                  <ChevronDown className="w-4 h-4 text-[#6B7280]" />
                </div>
                <input
                  type="tel"
                  value={recipient.phone}
                  onChange={(e) => setRecipient({ ...recipient, phone: e.target.value })}
                  placeholder="Phone number"
                  className="input-field flex-1"
                />
              </div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="px-6 py-4 border-t border-[#E5E5E5]">
          <button 
            onClick={() => recipient.name && recipient.phone && setScreen('payment-method')}
            disabled={!recipient.name || !recipient.phone}
            className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Continue
          </button>
        </div>
      </div>
    );
  }

  // Payment Method Screen
  if (screen === 'payment-method') {
    const paymentMethods = getPaymentMethods();
    
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('recipient')}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold">Select Payment Method</h2>
        </div>

        {/* Main Content */}
        <div className="flex-1 px-6 py-8">
          <div className="mb-6">
            <p className="text-sm text-[#6B7280] mb-2">How {recipient.name} will receive money in {receiveCountry.name}</p>
            <div className="flex items-center gap-2">
              <span className="text-2xl">{receiveCountry.flag}</span>
              <span className="font-semibold text-lg">{receiveCountry.currency} {calculateReceiveAmount()}</span>
            </div>
          </div>

          <p className="text-sm font-medium text-[#6B7280] mb-4">Available payment methods</p>
          
          <div className="space-y-3">
            {paymentMethods.map((method) => (
              <button
                key={method.id}
                onClick={() => {
                  setSelectedPaymentMethod(method);
                  setRecipient({ ...recipient, paymentMethod: method.name, paymentId: '' });
                }}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all ${
                  selectedPaymentMethod?.id === method.id
                    ? 'border-[#00A86B] bg-[#00A86B]/5'
                    : 'border-[#E5E5E5] hover:border-[#00A86B]/50'
                }`}
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-lg"
                  style={{ backgroundColor: method.color }}
                >
                  {method.icon}
                </div>
                <div className="flex-1 text-left">
                  <p className="font-semibold">{method.name}</p>
                  <p className="text-xs text-[#6B7280]">
                    {method.id === 'cashapp' && 'Fast & secure - US only'}
                    {method.id === 'zelle' && 'Direct bank transfer - US only'}
                    {method.id === 'paypal' && 'Global payments'}
                    {method.id === 'venmo' && 'Social payments - US only'}
                    {method.id === 'wise' && 'Low fees worldwide'}
                    {method.id === 'revolut' && 'Digital banking'}
                    {method.id === 'interac' && 'Canadian e-Transfer'}
                    {method.id === 'upi' && 'Instant India payments'}
                    {method.id === 'payid' && 'Australian instant transfer'}
                    {method.id === 'mobilemoney' && 'Mobile wallet delivery'}
                    {method.id === 'bank' && 'Direct to bank account'}
                  </p>
                </div>
                {selectedPaymentMethod?.id === method.id && (
                  <CheckCircle2 className="w-6 h-6 text-[#00A86B]" />
                )}
              </button>
            ))}
          </div>

          {/* Payment ID Input */}
          {selectedPaymentMethod && (
            <div className="mt-6 animate-slide-up">
              <label className="text-sm font-medium text-[#6B7280] mb-2 block">
                {selectedPaymentMethod.id === 'cashapp' && 'Cash App $Cashtag'}
                {selectedPaymentMethod.id === 'zelle' && 'Zelle Email or Phone'}
                {selectedPaymentMethod.id === 'paypal' && 'PayPal Email'}
                {selectedPaymentMethod.id === 'venmo' && 'Venmo Username'}
                {selectedPaymentMethod.id === 'wise' && 'Wise Email'}
                {selectedPaymentMethod.id === 'revolut' && 'Revolut Phone or Username'}
                {selectedPaymentMethod.id === 'interac' && 'Interac Email'}
                {selectedPaymentMethod.id === 'upi' && 'UPI ID'}
                {selectedPaymentMethod.id === 'payid' && 'PayID (Email/Phone)'}
                {selectedPaymentMethod.id === 'mobilemoney' && 'Mobile Money Number'}
                {selectedPaymentMethod.id === 'bank' && 'Bank Account Number'}
              </label>
              <input
                type="text"
                value={recipient.paymentId}
                onChange={(e) => setRecipient({ ...recipient, paymentId: e.target.value })}
                placeholder={
                  selectedPaymentMethod.id === 'cashapp' ? '$username'
                  : selectedPaymentMethod.id === 'paypal' ? 'email@example.com'
                  : selectedPaymentMethod.id === 'venmo' ? '@username'
                  : selectedPaymentMethod.id === 'upi' ? 'name@upi'
                  : 'Enter recipient details'
                }
                className="input-field"
              />
            </div>
          )}
        </div>

        {/* CTA */}
        <div className="px-6 py-4 border-t border-[#E5E5E5]">
          <button 
            onClick={() => selectedPaymentMethod && recipient.paymentId && setScreen('review')}
            disabled={!selectedPaymentMethod || !recipient.paymentId}
            className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Continue
          </button>
        </div>
      </div>
    );
  }

  // Review Screen
  if (screen === 'review') {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('payment-method')}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold">Review & Send</h2>
        </div>

        {/* Main Content */}
        <div className="flex-1 px-6 py-8">
          {/* Amount Card */}
          <div className="bg-[#F7F7F7] rounded-3xl p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-[#6B7280]">You send</p>
                <p className="text-2xl font-bold">{sendCountry.currency} {amount}</p>
              </div>
              <span className="text-3xl">{sendCountry.flag}</span>
            </div>

            <div className="flex items-center gap-3 my-4">
              <div className="w-8 h-8 bg-[#00A86B]/10 rounded-full flex items-center justify-center">
                <ArrowRight className="w-4 h-4 text-[#00A86B]" />
              </div>
              <div className="flex-1 h-px bg-[#E5E5E5]"></div>
              <p className="text-xs text-[#6B7280]">Instant</p>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#6B7280]">They receive</p>
                <p className="text-2xl font-bold text-[#00A86B]">{receiveCountry.currency} {calculateReceiveAmount()}</p>
              </div>
              <span className="text-3xl">{receiveCountry.flag}</span>
            </div>
          </div>

          {/* Recipient Card */}
          <div className="bg-[#F7F7F7] rounded-3xl p-6 mb-6">
            <p className="text-sm text-[#6B7280] mb-3">Sending to</p>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#00A86B] rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="font-semibold">{recipient.name}</p>
                <p className="text-sm text-[#6B7280]">{recipient.phone}</p>
              </div>
            </div>
          </div>

          {/* Payment Method Card */}
          <div className="bg-[#F7F7F7] rounded-3xl p-6 mb-6">
            <p className="text-sm text-[#6B7280] mb-3">Payment method</p>
            <div className="flex items-center gap-4">
              {selectedPaymentMethod && (
                <>
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold"
                    style={{ backgroundColor: selectedPaymentMethod.color }}
                  >
                    {selectedPaymentMethod.icon}
                  </div>
                  <div>
                    <p className="font-semibold">{selectedPaymentMethod.name}</p>
                    <p className="text-sm text-[#6B7280]">{recipient.paymentId}</p>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Details */}
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-[#6B7280]">Fee</span>
              <span className="font-medium text-[#00A86B]">Free</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-[#6B7280]">Exchange rate</span>
              <span className="font-medium">1 {sendCountry.currency} = {receiveCountry.currency} {getExchangeRate(sendCountry.currency, receiveCountry.currency).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-[#6B7280]">Delivery</span>
              <span className="font-medium flex items-center gap-1">
                <Clock className="w-4 h-4" />
                Instant
              </span>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="px-6 py-4 border-t border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('stripe-payment')}
            className="btn-primary flex items-center justify-center gap-2"
          >
            <CreditCard className="w-5 h-5" />
            Pay {sendCountry.currency} {amount}
          </button>
          <p className="text-center text-xs text-[#6B7280] mt-3">
            Secured by Stripe. By sending, you agree to our Terms of Service
          </p>
        </div>
      </div>
    );
  }

  // Stripe Payment Screen
  if (screen === 'stripe-payment') {
    return (
      <StripePayment
        amount={parseFloat(amount) || 0}
        currency={sendCountry.currency}
        recipientEmail={recipient.paymentId}
        recipientCountry={receiveCountry.name}
        paymentMethod={selectedPaymentMethod?.name || 'Bank Transfer'}
        senderId="user_123" // In production, get from auth
        recipientName={recipient.name}
        recipientPhone={recipient.phone}
        onSuccess={(transaction) => {
          console.log('Payment successful:', transaction);
          setScreen('success');
        }}
        onCancel={() => setScreen('review')}
      />
    );
  }

  // Success Screen
  if (screen === 'success') {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center px-6">
        <div className="text-center">
          <div className="w-24 h-24 bg-[#00A86B] rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Money Sent!</h2>
          <p className="text-[#6B7280] mb-8">
            {recipient.name} will receive {receiveCountry.currency} {calculateReceiveAmount()} shortly.
          </p>
          
          <div className="bg-[#F7F7F7] rounded-2xl p-6 mb-8 text-left">
            <div className="flex justify-between mb-3">
              <span className="text-[#6B7280]">Amount sent</span>
              <span className="font-semibold">{sendCountry.currency} {amount}</span>
            </div>
            <div className="flex justify-between mb-3">
              <span className="text-[#6B7280]">Recipient</span>
              <span className="font-semibold">{recipient.name}</span>
            </div>
            <div className="flex justify-between mb-3">
              <span className="text-[#6B7280]">Payment method</span>
              <span className="font-semibold">{selectedPaymentMethod?.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6B7280]">Reference</span>
              <span className="font-semibold">NK{Math.random().toString(36).substr(2, 8).toUpperCase()}</span>
            </div>
          </div>
          
          <button 
            onClick={() => {
              setScreen('welcome');
              setAmount('');
              setRecipient({ name: '', phone: '', paymentMethod: '', paymentId: '' });
              setSelectedPaymentMethod(null);
            }}
            className="btn-primary"
          >
            Send Another
          </button>
        </div>
      </div>
    );
  }

  // Bill Payment Screen
  if (screen === 'bill-payment' && selectedBillType) {
    const BillIcon = selectedBillType.icon;
    const providers = getProviders();
    
    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 py-4 border-b border-[#E5E5E5]">
          <button 
            onClick={() => setScreen('welcome')}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F7F7F7]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold">Pay {selectedBillType.name}</h2>
        </div>

        {/* Main Content */}
        <div className="flex-1 px-6 py-8">
          {/* Country & Bill Type Header */}
          <div className="flex items-center gap-4 mb-8">
            <div 
              className="w-16 h-16 rounded-2xl flex items-center justify-center"
              style={{ backgroundColor: `${selectedBillType.color}20` }}
            >
              <BillIcon className="w-8 h-8" style={{ color: selectedBillType.color }} />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xl">{billCountry.flag}</span>
                <span className="text-sm text-[#6B7280]">{billCountry.name}</span>
              </div>
              <p className="text-xl font-semibold">{selectedBillType.name}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-[#6B7280] mb-2 block">Provider/Company</label>
              <select 
                className="input-field w-full"
                value={billDetails.provider}
                onChange={(e) => setBillDetails({...billDetails, provider: e.target.value})}
              >
                <option value="">Select provider</option>
                {providers.length > 0 ? (
                  providers.map((provider) => (
                    <option key={provider} value={provider}>{provider}</option>
                  ))
                ) : (
                  <option value="">No providers available for this country</option>
                )}
              </select>
            </div>

            <div>
              <label className="text-sm font-medium text-[#6B7280] mb-2 block">Account/Meter Number</label>
              <input
                type="text"
                value={billDetails.accountNumber}
                onChange={(e) => setBillDetails({...billDetails, accountNumber: e.target.value})}
                placeholder="Enter account number"
                className="input-field"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-[#6B7280] mb-2 block">Amount</label>
              <div className="flex items-center gap-2">
                <span className="text-2xl text-[#6B7280]">{billCountry.currency}</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="input-field flex-1"
                />
              </div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="px-6 py-4 border-t border-[#E5E5E5]">
          <button 
            onClick={() => {
              if (billDetails.provider && billDetails.accountNumber && amount) {
                alert(`${selectedBillType.name} bill paid successfully!`);
                setScreen('welcome');
                setAmount('');
                setBillDetails({ accountNumber: '', provider: '' });
              }
            }}
            disabled={!billDetails.provider || !billDetails.accountNumber || !amount}
            className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Pay {billCountry.currency} {amount || '0'}
          </button>
        </div>
      </div>
    );
  }

  return null;
}

export default App;
