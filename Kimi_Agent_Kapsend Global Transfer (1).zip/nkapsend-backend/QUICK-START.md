# NKAPSEND Backend - Quick Start

## 📦 Files Included

```
nkapsend-backend/
├── server.js              # Main API server (11840 bytes)
├── package.json           # Dependencies
├── .env                   # Your PayPal credentials (CONFIGURED)
├── Procfile              # For Heroku deployment
├── render.yaml           # For Render deployment
├── README.md             # Full documentation
├── DEPLOY.md             # Deployment guide
├── DEPLOY-STEP-BY-STEP.md # Step-by-step instructions
└── .gitignore            # Git ignore file
```

## 🚀 Quick Deploy (Choose One)

### Option A: Render (FREE - Recommended)
1. Go to https://render.com
2. Sign up with GitHub
3. Click "New" → "Web Service"
4. Upload this folder
5. Add environment variables from `.env`
6. Click "Create"

**Your API will be live in 2-3 minutes!**

### Option B: Run Locally (For Testing)
```bash
cd nkapsend-backend
npm install
npm start
```

API runs at: `http://localhost:3001`

---

## ✅ Your PayPal is Configured

**Client ID:** `AZaq801tfmI5t_0zbg0ony-0Lw9g4wg7u53E1YmZpjZHVWtLJIWfTpTP9_YcauuGl9ldg4n6oPyCAGGj`

**Mode:** Sandbox (Test)

---

## 🔗 Connect to Frontend

After deploying, update your frontend:

**File:** `src/api.ts`
```typescript
const API_BASE_URL = 'https://YOUR-API-URL.onrender.com/api';
```

---

## 📡 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Check API status |
| `/api/auth/register` | POST | Create account |
| `/api/auth/login` | POST | Login |
| `/api/payments/create-intent` | POST | Create Stripe payment |
| `/api/paypal/create-order` | POST | Create PayPal order |
| `/api/paypal/capture` | POST | Capture PayPal payment |
| `/api/bills/pay` | POST | Pay bills |

---

## 🧪 Test After Deploy

```bash
curl https://YOUR-API-URL.onrender.com/api/health
```

Expected response:
```json
{
  "status": "ok",
  "paypal": "configured",
  "stripe": "not configured"
}
```

---

## 💳 To Enable REAL Money Transfers

1. ✅ Deploy backend (this step)
2. ⏳ Get Stripe keys from https://dashboard.stripe.com
3. ⏳ Switch PayPal to Live mode
4. ⏳ Update backend with live credentials

---

## 🆘 Need Help?

**Common Issues:**

**"Build failed"**
- Make sure `package.json` is included
- Check Node version is 18+

**"PayPal not working"**
- Verify Client ID is correct
- Check `PAYPAL_MODE=sandbox`

**"CORS error"**
- Update `FRONTEND_URL` in environment variables

---

**Ready to deploy!** 🚀
