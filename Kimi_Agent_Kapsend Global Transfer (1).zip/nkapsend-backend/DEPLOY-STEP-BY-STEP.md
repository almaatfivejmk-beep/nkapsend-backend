# Deploy NKAPSEND Backend - Step by Step

## Option 1: Render (Recommended - FREE)

### Step 1: Create Render Account
1. Go to https://render.com
2. Click "Get Started for Free"
3. Sign up with your GitHub account

### Step 2: Create New Web Service
1. In Render dashboard, click **"New"** → **"Web Service"**
2. Choose **"Deploy from Git URL"** (or upload the backend folder)
3. Enter this GitHub repo URL (if you upload to GitHub) OR use "Upload" option

### Step 3: Configure Service
Fill in these details:

| Field | Value |
|-------|-------|
| **Name** | `nkapsend-api` |
| **Environment** | `Node` |
| **Build Command** | `npm install` |
| **Start Command** | `npm start` |
| **Plan** | `Free` |

### Step 4: Add Environment Variables
Click "Advanced" and add these:

```
PAYPAL_CLIENT_ID=AZaq801tfmI5t_0zbg0ony-0Lw9g4wg7u53E1YmZpjZHVWtLJIWfTpTP9_YcauuGl9ldg4n6oPyCAGGj
PAYPAL_CLIENT_SECRET=EEC9_opqaTNNzPdih1_kqjmDBFsDW0A8Na873DfCMnhPLD-WHMD0Ga14eSGpA4I_jbie-fOfHPNFnlvQ
PAYPAL_MODE=sandbox
STRIPE_SECRET_KEY=sk_test_your_stripe_key_here
JWT_SECRET=nkapsend_secret_key_2024
FRONTEND_URL=https://q5zohaollehti.ok.kimi.link
```

### Step 5: Deploy!
Click **"Create Web Service"**

Wait 2-3 minutes for deployment.

### Step 6: Get Your API URL
Once deployed, you'll get a URL like:
```
https://nkapsend-api.onrender.com
```

### Step 7: Update Frontend
In your frontend code, update the API URL in `src/api.ts`:

```typescript
const API_BASE_URL = 'https://nkapsend-api.onrender.com/api';
```

---

## Option 2: Railway (FREE $5/month credit)

1. Go to https://railway.app
2. Sign up with GitHub
3. Click "New Project" → "Deploy from GitHub repo"
4. Upload backend folder to GitHub first
5. Deploy!

---

## Option 3: Heroku (Paid)

1. Go to https://heroku.com
2. Create account
3. Install Heroku CLI
4. Run:
```bash
heroku login
heroku create nkapsend-api
git push heroku main
```

---

## Test Your API

After deployment, test with:

```bash
curl https://YOUR-API-URL.onrender.com/api/health
```

Should return:
```json
{"status":"ok","paypal":"configured"}
```

---

## Need Help?

If you get stuck, share:
1. The error message
2. Which step you're on
3. Your Render dashboard URL

I'll help you fix it! 🚀
