# Deploy NKAPSEND Backend

## Quick Deploy to Render (Free)

### 1. Create Render Account
- Go to https://render.com
- Sign up with GitHub

### 2. Deploy Web Service
1. Click "New" → "Web Service"
2. Connect your GitHub repo (or use "Deploy from Git URL")
3. Configure:
   - **Name**: nkapsend-api
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`

### 3. Add Environment Variables
In Render dashboard, add these:

```
PAYPAL_CLIENT_ID=AcezLCKiWBlHsvTIJF6xT2N1hRJ6M0napwYDQLKAtiy_GvVQ9pV6NKroldj1qi7xSLVUNBO8Jytrqwim
PAYPAL_CLIENT_SECRET=EBaFzpYHY8OtCOtoS4PpwjX7vtuWariW5TUQhQbzl5GSOrY6IHJLTxuF-WMrDbd4Jm_cEXKIQMzaBkwT
PAYPAL_MODE=sandbox
STRIPE_SECRET_KEY=sk_test_your_key_here
STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here
JWT_SECRET=your_random_secret_here
FRONTEND_URL=https://q5zohaollehti.ok.kimi.link
```

### 4. Deploy!
Click "Create Web Service"

Your API will be live at: `https://nkapsend-api.onrender.com`

---

## Test the API

```bash
# Health check
curl https://nkapsend-api.onrender.com/api/health

# Get PayPal config
curl https://nkapsend-api.onrender.com/api/paypal/client-id
```

---

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Check API status |
| `/api/auth/register` | POST | Create account |
| `/api/auth/login` | POST | Login |
| `/api/payments/create-intent` | POST | Create Stripe payment |
| `/api/payments/confirm` | POST | Confirm payment |
| `/api/paypal/create-order` | POST | Create PayPal order |
| `/api/paypal/capture` | POST | Capture PayPal payment |
| `/api/paypal/client-id` | GET | Get PayPal client ID |
| `/api/bills/pay` | POST | Pay bills |
| `/api/transactions/:userId` | GET | Get transactions |

---

## Next Steps

1. **Get Stripe keys** from https://dashboard.stripe.com/apikeys
2. **Switch PayPal to Live** when ready (change `PAYPAL_MODE=live`)
3. **Add MongoDB** for persistent data
4. **Set up webhooks** for payment notifications
