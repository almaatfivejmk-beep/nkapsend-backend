# NKAPSEND Backend - Real Payment Integration

This backend connects NKAPSEND to real payment systems: **Stripe** and **PayPal**.

## 🚀 Quick Start

### 1. Get API Keys

#### Stripe (Required for card payments)
1. Go to https://dashboard.stripe.com/register
2. Create a free account
3. Get your API keys from https://dashboard.stripe.com/apikeys
4. Use **Test keys** for development

#### PayPal (Required for PayPal payments)
1. Go to https://developer.paypal.com/dashboard/
2. Create a developer account
3. Create a sandbox app
4. Get Client ID and Secret

### 2. Setup Environment

```bash
cd nkapsend-backend
cp .env.example .env
# Edit .env with your real API keys
```

### 3. Install & Run

```bash
npm install
npm start
```

Server runs on `http://localhost:3001`

## 📡 API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Create new user |
| POST | `/api/auth/login` | Login user |

### Payments (Stripe)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/payments/create-intent` | Create payment intent |
| POST | `/api/payments/confirm` | Confirm payment |

### PayPal
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/paypal/create-order` | Create PayPal order |
| POST | `/api/paypal/capture` | Capture payment |

### Bills
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/bills/pay` | Pay utility bills |

### Transactions
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/transactions/:userId` | Get user transactions |

## 💳 Payment Flow

### Sending Money (Stripe)
1. User enters amount & recipient
2. Frontend calls `/api/payments/create-intent`
3. Stripe returns `clientSecret`
4. Frontend uses Stripe.js to collect card
5. User confirms payment
6. Frontend calls `/api/payments/confirm`
7. Backend verifies & creates transaction

### Mobile Money → PayPal
1. User selects country & mobile provider
2. Frontend calls `/api/paypal/create-order`
3. User confirms on PayPal
4. Frontend calls `/api/paypal/capture`
5. Backend processes & creates transaction

## 🔐 Security

- All card data handled by Stripe (PCI compliant)
- PayPal handles their own security
- Use HTTPS in production
- Store API keys in environment variables
- Never expose secret keys to frontend

## 🛠️ Production Checklist

- [ ] Switch to Stripe Live keys
- [ ] Switch to PayPal Production
- [ ] Set up MongoDB database
- [ ] Add JWT authentication
- [ ] Implement rate limiting
- [ ] Add webhook verification
- [ ] Set up SSL/HTTPS
- [ ] Add error monitoring (Sentry)
- [ ] Implement KYC verification
- [ ] Get money transmitter licenses

## 📞 Support

For issues with:
- **Stripe**: https://support.stripe.com
- **PayPal**: https://developer.paypal.com/support
